Las instancias, es decir, los tests se encuentran dentro de las siguientes 3 carpetas:

--CycleGraph

--GridGraph

--PathGraph

Las instancias están organizadas de acuerdo al tipo de grafo que representan