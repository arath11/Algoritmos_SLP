Dentro de esta carpeta se encuentran las siguientes carpetas

--Archivos Java (En esta carpeta se encuentran todos los progamas que utilizamos, librerías e instancias)

--README (Dentro de esta carpeta se encuentra un readme para poder conocer cómo ejecutar el programa
          correctamente mediante terminal)

--Reporte Actualizado (Dentro de esta carpeta se encuentra el respaldo del reporte final del proyecto)

--Video (Dentro de esta carpeta se encunetra el respaldo del vídeo final)

Equipo:
Julio Arath Rosales Oliden 	A01630738
Lizbeth Ortiz López 		A00227346
Marlene Rodríguez Harms 	A00227347
Reynaldo Vega Menchaca 		A01114523
