Dentro de esta carpeta se encuentra los siguientes archivos

--test11

--test12

--test13

--test14

--test15

--test11.txt

--test12.txt

--test13.txt

--test14.txt

--test15.txt

Todos los archivos .txt son las instancias que corrimos para el algoritmo y dentro de las carpetas
se encuentran screenshots de los experimentos que realizamos
