Dentro de esta carpeta se encuentra los siguientes archivos

--test01

--test02

--test03

--test04

--test05

--test01.txt

--test02.txt

--test03.txt

--test04.txt

--test05.txt

Todos los archivos .txt son las instancias que corrimos para el algoritmo y dentro de las carpetas
se encuentran screenshots de los experimentos que realizamos
