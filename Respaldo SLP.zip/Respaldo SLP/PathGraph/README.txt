Dentro de esta carpeta se encuentra los siguientes archivos

--test06

--test07

--test08

--test09

--test10

--test06.txt

--test07.txt

--test08.txt

--test09.txt

--test10.txt

Todos los archivos .txt son las instancias que corrimos para el algoritmo y dentro de las carpetas
se encuentran screenshots de los experimentos que realizamos
