Dentro de esta carpeta se encuentran las siguientes carpetas:

--CycleGraph

--GridGraph

--PathGraph

En cada una de ellas se encuentran tanto las instancias como los respaldos de los experimentos de las ejecuciones
del algoritmo